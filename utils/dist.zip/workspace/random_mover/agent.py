from game import *
from collections.abc import Callable
from typing import List, Tuple
import numpy as np

import os


class PlayerAgent:
    """
    /you may add functions, however, __init__ and play are the entry points for 
    your program and should not be changed.
    """
    def __init__(self, time_left: Callable):
        self.trapdoors = []
        return

    def play(
        self, 
        board:player_board.PlayerBoard, 
        sensor_data:List[Tuple[bool, bool]], 
        time_left: Callable):

        moves = board.get_valid_moves()
        print("Hello")
        selection = (int) (len(moves) * np.random.random())
        return moves[selection]




def main():
    import os
    from gameplay import play_game, validate_submission
    from game.enums import Result
    from board_utils import get_history_json

    import time
    import json
    # parser = argparse.ArgumentParser(description='Run a game between two players')
    # parser.add_argument('--a_name', '-a', type=str, help='Name of player A submission', required=True)
    # parser.add_argument('--b_name', '-b', type=str, help='Name of player B submission', required=True)
    #args = parser.parse_args()
    sim_time = time.perf_counter()

    game_sub_dir = os.path.join(os.getcwd(),"game_env", "game_subs")
    play_directory =  os.path.join(game_sub_dir, "temp")

    player_a_name = "player_a"
    player_b_name = "player_b"

    final_board, err_a, err_b = play_game(play_directory, play_directory, 
                                        player_a_name, player_b_name, 
                                        display_game=True, delay = 0.1, clear_screen = False, 
                                        record = True, limit_resources=False)  
    

    sim_time = time.perf_counter() - sim_time
    turn_count = final_board.turn_count
    print(f"{sim_time} seconds elapsed for {turn_count} rounds.")

    out_file = 'result.json'
    out_dir = os.path.join(os.getcwd(), "game_env", "match_runs") 

    with open(os.path.join(out_dir, out_file), 'w') as fp:
        fp.write(get_history_json(final_board))


if __name__=="__main__":
    main()

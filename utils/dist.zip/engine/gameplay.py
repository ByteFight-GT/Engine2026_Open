
from game import board, game_map, player_board
from game.board import Board
from game.game_map import GameMap
from game.enums import Result, WinReason, Direction, MoveType
from game.player_board import PlayerBoard
from board_utils import get_board_string
from collections.abc import Iterable
from player_process import PlayerProcess
import time




def init_display(board, player_a_name, player_b_name):
    print(player_a_name+ " vs. "+player_b_name)
    print("\nA to play" if board.is_as_turn() else "\nB to play")


#prints board to terminal, clearing on each round
def print_board(board, a_time, b_time, clear_screen):
    player_map, a_eggs, b_eggs, a_turds, b_turds = get_board_string(board)

    import os

    if(clear_screen):
        os.system("cls||clear")

    board_list  = []

    board_list.append("TURN "+str(board.turn_count)+"\n")
    if(board.is_as_turn()):
        board_list.append("A to play, Time left:"+str(a_time)+"\n")
    else:
        board_list.append("B to play, Time left:"+str(b_time)+"\n")
    
    board_list.append("MAP:\n")
    board_list.append(player_map+"\n")
    board_list.append("EGGS Player A:"+str(a_eggs) + " Player B:"+ str(b_eggs)+"\n")
    board_list.append("TURDS Player A:"+str(a_turds) + " Player B:"+ str(b_turds)+"\n\n")

    print("".join(board_list), end="")

    
    

# prints a player's move on a given turn
def print_moves(player_as_turn, moves, timer):
    dir, movetype = moves
    try:
        if(player_as_turn):
            print("Player A plays:", end="")
        else:
            print("Player B plays:", end="")
        if(moves is None):
            print("None", end='')
        else:
            print(f"{Direction(dir).name}, {MoveType(movetype).name}", end='')
    except:
        print("Invalid", end='')


    print(f" in {timer} seconds")

def validate_submission(directory_a, player_a_name, limit_resources=False, use_gpu = False):
    from multiprocessing import Process, Queue, set_start_method

    import traceback
    import importlib.util
    import sys
    import subprocess
    player_a_process = None

    try:
        if(not directory_a  in sys.path):
            sys.path.append(directory_a)


        play_time = 300
        extra_ret_time = 5

        #setup main thread queue for getting results
        main_q = Queue()

        #setup two thread queues for passing commands to players
        player_a_q = Queue()
        map_to_play = GameMap()
        

        queues = [player_a_q, main_q]

        out_queue = Queue()

        game_board = Board(map_to_play, play_time, build_history=False, randomize=False) 
        player_a_process = PlayerProcess(True, player_a_name, directory_a, 
                                     player_a_q, main_q, limit_resources, use_gpu, 
                                     out_queue, user_name="player_a_user", 
                                     group_name="player_a")
        player_a_process.start()

        ok = main_q.get(block = True, timeout = 10) 
        message = ""

        if(not ok):
            message = "Failed to initialize agent"
        else:
            init_timeout = 10
            ok, message = player_a_process.run_timed_constructor(init_timeout, 10)

        if ok:
            moves, timer, message = player_a_process.run_timed_play(game_board, game_board.get_a_time(), extra_ret_time)
            ok = not moves is None

        terminate_validation(player_a_process, queues, out_queue)
        return ok, message
    except:
        print(traceback.format_exc())

        if(player_a_process.process):
            terminate_validation(player_a_process, queues, out_queue)
        return False, traceback.format_exc()
    
def delete_module(name):
    import sys
    if name in sys.modules:
        del sys.modules[name]


def terminate_validation(process_a, queues, out_queue):
    delete_module("player_a.agent")
    delete_module("player_a")
    
    process_a.terminate_process_and_children()

    for q in queues:
        try:
            while True:
                q.get_nowait()
        except:
            pass

    try:
        while True:
            out_queue.get_nowait()
    except:
        pass
    

# Listener function to continuously listen to the queue
def listen_for_output(output_queue, stop_event):
    while not stop_event.is_set():
        try:
            print(output_queue.get(timeout=1))  # Wait for 1 second for output
        except:
            continue  # No output yet, continue listening

def play_game(directory_a, directory_b, player_a_name, player_b_name, 
              display_game = False, delay = 0, 
              clear_screen=True, record = True, limit_resources=False, use_gpu = False):
    #setup main environment, import player modules
    from multiprocessing import Process, Queue
    

    
    import traceback

    import threading
    import sys
    import os

    if(not directory_a  in sys.path):
        sys.path.append(directory_a)

    if(not directory_b  in sys.path):
        sys.path.append(directory_b)

    play_time = 300
    extra_ret_time = 5
    init_timeout = 10

    if(not limit_resources):
        init_timeout = 20
        play_time = 300

    #setup main thread queue for getting results
    main_q_a = Queue()
    main_q_b = Queue()

    #setup two thread queues for passing commands to players
    player_a_q = Queue()
    player_b_q = Queue()

    #game init
    map_to_play = GameMap()
    game_board = Board(map_to_play, play_time, build_history=record, randomize=True)     

    out_queue = Queue()
    stop_event = None
    if(not limit_resources):
        stop_event = threading.Event()
        listener_thread = threading.Thread(target=listen_for_output, args=(out_queue, stop_event))
        listener_thread.daemon = True
        listener_thread.start()

    queues = [player_a_q, player_b_q, main_q_a, main_q_b]

    #startup two player processes    
    player_a_process = PlayerProcess(True, player_a_name, directory_a, 
                                     player_a_q, main_q_a, limit_resources, use_gpu, 
                                     out_queue, user_name="player_a_user", 
                                     group_name="player_a")
    
    player_b_process = PlayerProcess(False, player_b_name, directory_b, 
                                     player_b_q, main_q_b, limit_resources, use_gpu,
                                     out_queue, user_name="player_b_user", 
                                     group_name="player_b")

    success_a = False
    success_b = False

    message_a = ""
    message_b = ""
    
    try:
        player_a_process.start()
        success_a = main_q_a.get(block = True, timeout = 1) 
        player_a_process.pause_process_and_children()
    except Exception as e:
        message_a = traceback.format_exc()
        print(f"Player a crashed during initialization: {message_a}")
    
    try:
        player_b_process.start() 
        success_b = main_q_b.get(block = True, timeout = 1) 
        player_b_process.pause_process_and_children()
    except Exception as e:
        message_b = traceback.format_exc()
        print(f"Player b crashed during initialization: {message_b}")  


    if(success_a and success_b):
        player_a_process.restart_process_and_children()
        success_a, message_a = player_a_process.run_timed_constructor(init_timeout, extra_ret_time)
        player_a_process.pause_process_and_children()

        player_b_process.restart_process_and_children()
        success_b, message_b = player_b_process.run_timed_constructor(init_timeout, extra_ret_time)
        player_b_process.pause_process_and_children()

    
    if(not success_a and not success_b):
        game_board.set_winner(Result.TIE, WinReason.FAILED_INIT)
        terminate_game(player_a_process, player_b_process, queues, out_queue, stop_event)
        return game_board, message_a, message_b
    elif(not success_a):
        game_board.set_winner(Result.PLAYER_B, WinReason.FAILED_INIT)
        terminate_game(player_a_process, player_b_process, queues, out_queue, stop_event)
        return game_board, message_a, message_b
    elif(not success_b):
        game_board.set_winner(Result.PLAYER_A, WinReason.FAILED_INIT)
        terminate_game(player_a_process, player_b_process, queues, out_queue, stop_event)
        return game_board, message_a, message_b

    # start actual gameplay     
    # 
    
    timer = 0
    while(game_board.turn_count < 2 * game_board.MAX_TURNS and not game_board.is_game_over()):
        if display_game:
            init_display(game_board, "PLAYER A", "PLAYER B")

        if(display_game):
            print_board(game_board, game_board.get_a_time(), game_board.get_b_time(), clear_screen)

      
        if(game_board.is_as_turn()):
            # run a's turn
            player_a_process.restart_process_and_children()
            moves, timer, message_a = player_a_process.run_timed_play(game_board, game_board.get_a_time(), extra_ret_time)
            player_a_process.pause_process_and_children()

         
            if(game_board.get_winner() is None):
                
                if moves is None:
                    if(timer == -1):
                        game_board.set_winner(Result.PLAYER_B, WinReason.CODE_CRASH)
                    elif(timer == -2):
                        game_board.set_winner(Result.PLAYER_B, WinReason.MEMORY_ERROR)
                    else:
                        game_board.set_winner(Result.PLAYER_B,  WinReason.TIMEOUT)
                else:
                    dir, move_type = moves
                    valid = game_board.apply_move(dir, move_type,True, timer=timer)

                    if game_board.get_a_time() <= 0:
                        game_board.set_winner(Result.PLAYER_B, WinReason.TIMEOUT)

                    elif not valid:
                        message_a = f"{moves}"
                        game_board.set_winner(Result.PLAYER_B, WinReason.INVALID_TURN)

        else:
            # run b's turn
            player_b_process.restart_process_and_children()
            moves, timer, message_b = player_b_process.run_timed_play(game_board, game_board.get_b_time(), extra_ret_time)
            player_b_process.pause_process_and_children()

            if(game_board.get_winner() is None):
                if moves is None:
                    if(timer == -1):
                        game_board.set_winner(Result.PLAYER_A, WinReason.CODE_CRASH)
                    elif(timer == -2):
                        game_board.set_winner(Result.PLAYER_A, WinReason.MEMORY_ERROR)
                    else:
                        # print("hello1")
                        game_board.set_winner(Result.PLAYER_A, WinReason.TIMEOUT)
                else:
                    dir, move_type = moves
                    valid = game_board.apply_move(dir, move_type,False, timer=timer)

                    if game_board.get_b_time() <= 0:
                        game_board.set_winner(Result.PLAYER_A, WinReason.TIMEOUT)

                    elif not valid:
                        # print("hello2")
                        message_b = "{moves}"
                        game_board.set_winner(Result.PLAYER_A, WinReason.INVALID_TURN)

            
        if(not moves is None and display_game):
            print_moves(not game_board.is_as_turn(), moves, timer)
            time.sleep(delay)

        if(game_board.is_game_over()):
            if(display_game):
                print(f"{game_board.get_winner().name} wins by {game_board.get_win_reason().name}")

    terminate_game(player_a_process, player_b_process, queues, out_queue, stop_event)
    return game_board, message_a, message_b


# closes down player processes
def terminate_game(process_a, process_b, queues, out_queue, stop_event):

    delete_module("player_a"+"."+"agent")
    delete_module("player_a")
    delete_module("player_b"+"."+"agent")
    delete_module("player_b")


    if(not stop_event is None):
        stop_event.set()
        try:
            while True:
                print(out_queue.get_nowait())
        except:
            pass
    
    process_a.terminate_process_and_children()
    process_b.terminate_process_and_children()
    
    for q in queues:
        try:
            while True:
                q.get_nowait()
        except:
            pass


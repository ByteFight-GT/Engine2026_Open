from game.enums import MoveType, WinReason, Cell
from game.board import Board
from game.history import History
import numpy as np

def get_board_string(board:Board):
    """
    Returns a string representation of the current state of the board.
    """

    main_list = []

    a_x, a_y = board.chicken_a.get_location()
    b_x, b_y = board.chicken_b.get_location()

    main_list.append("  ")
    for x in range (board.game_map.MAP_SIZE):
        main_list.append(f"{x} ")
    main_list.append("\n")

    for y in range(board.game_map.MAP_SIZE):
        main_list.append(f"{y} ")
        for x in range (board.game_map.MAP_SIZE):
            if(a_x == x and a_y == y):
                main_list.append("@ ")
            elif(b_x == x and b_y == y):
                main_list.append("& ")
            elif(board.cells_eggsturds[y,x] == Cell.PLAYER_A_EGG):
                main_list.append("a ")
            elif(board.cells_eggsturds[y,x] == Cell.PLAYER_A_TURD):
                main_list.append("A ")
            elif(board.cells_eggsturds[y,x] == Cell.PLAYER_B_EGG):
                main_list.append("b ")
            elif(board.cells_eggsturds[y,x] == Cell.PLAYER_B_TURD):
                main_list.append("B ")
            elif(board.cells_trapdoors[y,x] > 0):
                main_list.append("T ")
            else:
                main_list.append("  ")

        main_list.append("\n")

    return_string = "".join(main_list)
    return return_string, board.chicken_a.get_eggs_laid(), board.chicken_b.get_eggs_laid(), \
        board.chicken_a.get_turds_left(), board.chicken_b.get_turds_left()



def get_history_dict(board:Board, errlog_a="", errlog_b=""):
    board_hist = board.history
    history_dict =  {
        'pos': board_hist.pos,
        'left_behind_enums': board_hist.left_behind_enums,
        'a_eggs_laid': board_hist.a_eggs_laid,
        'b_eggs_laid': board_hist.b_eggs_laid,
        'a_turds_left': board_hist.a_turds_left,
        'b_turds_left': board_hist.b_turds_left,
        'a_time_left': board_hist.a_time_left,
        'b_time_left': board_hist.b_time_left,
        'a_moves_left': board_hist.a_moves_left,
        'b_moves_left': board_hist.b_moves_left,
        "trapdoor_triggered": board_hist.trapdoor_triggered
    }


    left_behind = []
    for val in history_dict["left_behind_enums"]:
         match val:
            case MoveType.PLAIN:
                left_behind.append("plain")
            case MoveType.EGG:
                left_behind.append("egg")
            case MoveType.TURD:
                left_behind.append("turd")
            case _:
                left_behind.append("plain")
    history_dict["left_behind"] = left_behind
    history_dict.pop('left_behind_enums', None) 
         
    history_dict.pop('map', None) 

    history_dict["errlog_a"] = errlog_a
    history_dict["errlog_b"] = errlog_b

    history_dict["start_time"] = board.time_to_play
    history_dict["start_moves"] = board.MAX_TURNS

    history_dict["turn_count"] = board.turn_count
    history_dict["result"] = board.winner
    history_dict["reason"] = WinReason(board.win_reason).name

    history_dict["spawn_a"] = board.chicken_a.get_spawn()
    history_dict["spawn_b"] = board.chicken_b.get_spawn()
    history_dict["trapdoors"] = board.trapdoors
    
    
    return history_dict
    

def get_history_json(board:Board, err_a="", err_b=""):
    """
    Encodes the entire history of the game in a format readable by the renderer.
    """
    import json
    class NpEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, np.integer):
                return int(obj)
            if isinstance(obj, np.floating):
                return float(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return super(NpEncoder, self).default(obj)

    return json.dumps(get_history_dict(board, err_a, err_b), cls=NpEncoder)
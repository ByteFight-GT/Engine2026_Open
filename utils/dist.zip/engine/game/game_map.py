import numpy as np


class GameMap:
    """
    GameMap is an internal utility class used by board to initialize 
    constants and store immutable map data for the board. Also used
    to generate trapdoors. Do not use the functions in this class, they
    will not be helpful to you. If you want to use the class variables, 
    you may by accessing them through
    the playerboard.game_board.game_map
    """
    def __init__(self):
        self.MAP_SIZE = 8
        self.MAX_TRAPDOOR_DIST_FROM_CENTER = 2
        self.NUM_TRAPDOORS_PER_TEAM = 1
        self.MAX_TURDS = 5


        self.trapdoor_weights_a = np.zeros((self.MAP_SIZE, self.MAP_SIZE))
        self.trapdoor_weights_b = np.zeros((self.MAP_SIZE, self.MAP_SIZE))

        self.hear_base_mask = np.array(
            [
                [0, 0.1, 0.1, 0.1, 0],
                [0.1, 0.25, 0.5, 0.25, 0.1],
                [0.1, 0.5, 1, 0.5, 0.1],
                [0.1, 0.25, 0.5, 0.5, 0.1],
                [0, 0.1, 0.1, 0.1, 0]
            ])
        
        self.feel_base_mask = np.array(
            [
                [0.15, 0.3, 0.15],
                [0.3, 0.5, 0.3],
                [0.1, 0.3, 0.15],
            ])
        
        map_center = (self.MAP_SIZE/2)
        for i in range(self.MAP_SIZE):
            for j in range(self.MAP_SIZE):
                dist_y  = i - map_center
                dist_x = j - map_center
                if(dist_y >= 0):
                    dist_y += 1
                else:
                    dist_y = np.abs(dist_y)
                if(dist_x >= 0):
                    dist_x += 1
                else:
                    dist_x = np.abs(dist_x)
                
                weight = (self.MAX_TRAPDOOR_DIST_FROM_CENTER + 1) - max(dist_x, dist_y)
                if((i+ j) %2) == 0:
                    self.trapdoor_weights_a[i,j] = max(0, weight)
                else:
                    self.trapdoor_weights_b[i,j] = max(0, weight)


        self.trapdoor_weights_a /= np.sum(self.trapdoor_weights_a)
        self.trapdoor_weights_b /= np.sum(self.trapdoor_weights_b)

    def get_trapdoors_and_spawns(self):
        flattened_weights_a = self.trapdoor_weights_a.flatten() 
        flattened_weights_b = self.trapdoor_weights_b.flatten()
        

        trapdoors_indices_a = np.random.choice(len(flattened_weights_a), 
                                                p = flattened_weights_a, 
                                                size = self.NUM_TRAPDOORS_PER_TEAM, 
                                                replace = False)
        trapdoors_indices_b = np.random.choice(len(flattened_weights_b), 
                                                p = flattened_weights_b, 
                                                size = self.NUM_TRAPDOORS_PER_TEAM, 
                                                replace = False)
        
        trapdoors_a = []
        trapdoors_b = []

        for index in trapdoors_indices_a:
            trapdoors_a.append((index % self.MAP_SIZE, index// self.MAP_SIZE))

        for index in trapdoors_indices_b:
            trapdoors_b.append((index % self.MAP_SIZE, index// self.MAP_SIZE))

        spawn_weights = np.zeros((self.MAP_SIZE, self.MAP_SIZE))
        spawn_symmetry = np.zeros((self.MAP_SIZE, self.MAP_SIZE)) # 1 for horizontal, 0 for vertical
        for i in range(0, self.MAP_SIZE):
            if(i %2 == 0):
                spawn_weights[i, 0] = 1 if self.is_valid_spawn_square(i, 0, trapdoors_a, trapdoors_b, 1) else 0
                spawn_weights[0, i] = 1 if self.is_valid_spawn_square(0, i, trapdoors_a, trapdoors_b) else 0
                spawn_symmetry[0, i] = 1
                spawn_weights[i, self.MAP_SIZE-1] = 1 if self.is_valid_spawn_square(i, self.MAP_SIZE-1, trapdoors_a, trapdoors_b, 1) else 0 
                spawn_weights[self.MAP_SIZE-1, i] = 1 if self.is_valid_spawn_square(self.MAP_SIZE-1, i, trapdoors_a, trapdoors_b) else 0
                spawn_symmetry[self.MAP_SIZE-1, i] = 1


        flattened_spawns_a = spawn_weights.flatten() / np.sum(spawn_weights)
        spawn_index_a = np.random.choice(len(flattened_spawns_a), p=flattened_spawns_a)
        spawn_a = (spawn_index_a % self.MAP_SIZE,spawn_index_a // self.MAP_SIZE )
        spawn_b = self.reflect(spawn_a, spawn_symmetry[spawn_a[1], spawn_a[0]])

            
        return trapdoors_a, trapdoors_b, spawn_a, spawn_b
    
    def is_valid_spawn_square(self, x, y, trapdoors_a, trapdoors_b, symmetry=0):
        reflect_x, reflect_y = self.reflect((x, y), symmetry)

        for trap_x, trap_y in trapdoors_a:
            if abs(x- trap_x) + abs(y-trap_y) <=1:
                return False
            
        for trap_x, trap_y in trapdoors_b:
            if abs(x- trap_x) + abs(y-trap_y) <=1:
                return False
            
        for trap_x, trap_y in trapdoors_a:
            if abs(reflect_x- trap_x) + abs(reflect_y-trap_y) <=1:
                return False
            
        for trap_x, trap_y in trapdoors_b:
            if abs(reflect_x- trap_x) + abs(reflect_y-trap_y) <=1:
                return False
            
        return True
        
        

    def reflect(self, coords, symmetry):
        """
        Reflects coordinates across the map given a type of symmetry.
        """
        x, y = coords
        match symmetry:
            case 0: # horizontal
                return (self.MAP_SIZE-1-x, y)
            case 1: # vertical
                return (x, self.MAP_SIZE-1-y)
            case 2: #origin
                return (self.MAP_SIZE-1-x, self.MAP_SIZE-1-y)



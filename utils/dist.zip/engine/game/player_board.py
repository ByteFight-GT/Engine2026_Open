from game.board import Board
from game.enums import Cell, Result, Direction, MoveType, WinReason
import numpy as np
from enum import IntEnum, auto
from typing import Tuple, List


class PlayerBoard:
    """
    A wrapper around the Board class to be able to call board and
    chicken functions from the player's perspective. 
    
    There are two ways to call functions in your opponent's perspective. 
    1. You may call functions with the "enemy" parameter as True.  
    2. You may instead reverse the perspective of the board
    through apply_move, forecast, or reverse_perspective. This will allow you to
    call functions from your opponents perspective. 

    The playerboard you are passed will have the trapdoors unset, meaning you
    will have to keep track of the trapdoors yourself and set them at the beginning
    of each turn.  Trapdoor data is held
    by the game runner, so you will have to find and set the trapdoors yourself via set_trapdoor.
    Before then, any functions trying to get trapdoor data will not return anything valuable.

    Any coordinates should be given to the player_board functions in the form of x, y.
    Game objects are displayed, indexed, and stored on the 
    board arrays as arr[y, x] for geometrical accuracy. Any functions that return
    mask arrays of the board that should be indexed by [y, x].

    Check_validity/check_ok is on by default for most functions, but slows
    down execution. If a player is confident their actions are valid,
    they can directly apply turns and moves with check_validity as false.

    Be wary that invalid actions/turns/function calls could lead to functions throwing
    errors, so make sure to handle them with a try/except in case so that
    your program doesn't crash. If an apply function throws an error,
    it is not guarenteed that the board state will be valid or that the state
    will be the same as when the function started.
    """
    def __init__(self, is_player_a:bool, game_board: Board):
        """
        Parameters:  
            is_player_a (bool): If True, the player is player A; if False, the player is player B.
            game_board (Board): The game board object that holds the state of the current match.
        """
        
        self.game_board = game_board
        self.is_player_a = is_player_a

        self.chicken_player = game_board.chicken_a if is_player_a else game_board.chicken_b
        self.chicken_enemy = game_board.chicken_b if is_player_a else game_board.chicken_a

        self.player_cells_blocked = game_board.cells_blocked_a if is_player_a else game_board.cells_blocked_b
        self.enemy_cells_blocked = game_board.cells_blocked_b if is_player_a else game_board.cells_blocked_a

        self.player_egg_list = game_board.egg_list_a if is_player_a else game_board.egg_list_b
        self.enemy_egg_list = game_board.egg_list_b if is_player_a else game_board.egg_list_a

        self.player_turd_list = game_board.turd_list_a if is_player_a else game_board.egg_list_b
        self.enemy_turd_list = game_board.turd_list_b if is_player_a else game_board.turd_list_a

    ######################################################
    # BOARD STATE READING FUNCTIONS
    def get_dim_board(self) -> int:
        """
        Returns one dimension of the board.

        Returns:  
            (int): Dimension of the board.
        """
        return self.game_board.game_map.MAP_SIZE
    
    def get_turn_count(self) -> int:
        """
        Returns the total number of turns that have been played.

        Returns:
            (int): Number of turns played
        """
        return self.game_board.turn_count

    
    def is_game_over(self) -> bool:
        """
        Checks if the game is over by determining if a winner
        has been set. Win conditions are checked by the game
        at the end of every turn.

        Returns:  
            bool: True if the game is over, False otherwise.
        """
        return self.game_board.is_game_over()
    
    def get_egg_list(self, enemy:bool = False) -> List[Tuple[int, int]]:
        """
        Returns a copy of the list of laid eggs positions 
        for the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's egg list; if False, returns player's egg list.

        Returns:
            (List[Tuple[int, int]]): A copy of the egg position list.
        """
        if enemy:
            return self.enemy_egg_list[:]
        return self.player_egg_list[:]
    
    def get_turd_list(self, enemy:bool = False) -> List[Tuple[int, int]]:
        """
        Returns a copy of the list of placed turd positions 
        for the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's turd list; if False, returns player's turd list.

        Returns:
            (List[Tuple[int, int]]): A copy of the turd position list.
        """
        if(enemy):
            return self.enemy_turd_list[:]
        return self.player_turd_list[:]

    def get_cells_blocked(self, enemy:bool = False) -> np.ndarray:
        """
        Returns a copy of the blocked cells array for the player or enemy.
        
        Parameters:
            enemy (bool, optional): If True, returns enemy's blocked cells; if False, returns player's blocked cells.

        Returns:
            (np.ndarray): A 2D array where blocked cells have values > 0, indexed by [y, x].
        """
        if(enemy):
            return np.array(self.enemy_cells_blocked)
        return np.array(self.player_cells_blocked)
    
    def get_cells_eggsturds(self) -> np.ndarray:
        """
        Returns a mask of the board with the cells containing
        eggs and turds marked with enums.

        Returns:
            (np.ndarray): A 2D array indicating egg and turd locations, indexed by [y, x].
        """
        return np.array(self.game_board.cells_eggsturds)
    
    def cell_has_eggsturds(self, x: int, y: int) -> Cell:
        """
        Checks if a specific cell contains an egg or turd.

        Parameters:
            x (int): The x-coordinate of the cell.
            y (int): The y-coordinate of the cell.

        Returns:
            (Cell): The Cell enum value indicating what is at that location.
        """
        return Cell(self.game_board.cells_eggsturds[y][x])
    
    def is_cell_blocked(self, x, y, enemy:bool = False) -> bool:
        """
        Checks if a specific cell is blocked for the player or enemy.

        Parameters:
            x (int): The x-coordinate of the cell.
            y (int): The y-coordinate of the cell.
            enemy (bool, optional): If True, checks enemy's blocked cells; if False, checks player's blocked cells.

        Returns:
            (bool): True if the cell is blocked, False otherwise.
        """
        if(enemy):
            return self.enemy_cells_blocked[y,x] > 0
        return self.player_cells_blocked[y,x] > 0
    
    def get_trapdoors(self) -> List[Tuple[int, int]]:
        """
        Returns a copy of the trapdoor list.

        Returns:
            (List[Tuple[int, int]]): Array containing trapdoor positions.
        """
        return self.game_board.trapdoors[:]

    def has_trapdoor(self, x:int , y:int) -> bool:
        """
        Checks if a specific cell has a trapdoor.

        Parameters:
            x (int): The x-coordinate of the cell.
            y (int): The y-coordinate of the cell.

        Returns:
            (bool): True if there is a trapdoor at that location, False otherwise.
        """
        return self.game_board.cells_trapdoors[y,x] > 0
    
    def get_num_trapdoors_set(self)-> int:
        """
        Returns the number of trapdoors that have been set.

        Returns:
            (int): Number of trapdoors currently marked.
        """
        return self.game_board.trapdoors_marked

    def get_turns_left(self, enemy: bool=False) -> int:
        """
        Returns the number of turns remaining for the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's turns left; if False, returns player's turns left.

        Returns:
            (int): Number of turns remaining.
        """
        if(self.is_player_a != enemy):
            return self.game_board.turns_left_a
        return self.game_board.turns_left_b
    
    def get_am_player_a(self, enemy: bool = False) -> bool:
        """
        Checks if the current perspective is player A.

        Parameters:
            enemy (bool, optional): If True, checks if enemy is player A; if False, checks if player is player A.

        Returns:
            (bool): True if the specified player is player A, False otherwise.
        """
        return self.is_player_a != enemy

    def has_moves_left(self, enemy:bool = False) -> bool:
        """
        Checks if the player or enemy has moves remaining.

        Parameters:
            enemy (bool, optional): If True, checks enemy's moves; if False, checks player's moves.

        Returns:
            (bool): True if there are moves left, False otherwise.
        """
        return self.game_board.has_moves_left(self.is_player_a != enemy)

    def is_valid_cell(self, x:int, y:int) -> bool:
        """
        Checks if the given coordinates are within the valid board boundaries.

        Parameters:
            x (int): The x-coordinate to check.
            y (int): The y-coordinate to check.

        Returns:
            (bool): True if the cell is valid, False otherwise.
        """
        return self.game_board.is_valid_cell(x, y)

    def is_valid_move(self, dir:Direction | int, move_type:MoveType | int, enemy:bool = False) -> bool:
        """
        Checks if a move is valid for the player or enemy.

        Parameters:
            dir (Direction or int): The direction of the move.
            move_type (MoveType or int): The type of move (walk, run, fly).
            enemy (bool, optional): If True, checks validity for enemy; if False, checks for player.

        Returns:
            (bool): True if the move is valid, False otherwise.
        """
        return self.game_board.is_valid_move(dir, move_type, self.is_player_a != enemy)
    
    def can_lay_egg(self, enemy:bool=False) -> bool:
        """
        Checks if the player or enemy can lay an egg at their current location.

        Parameters:
            enemy (bool, optional): If True, checks for enemy; if False, checks for player.

        Returns:
            (bool): True if an egg can be laid, False otherwise.
        """
        return self.game_board.can_lay_egg(self.is_player_a != enemy)
    
    def can_lay_egg_at_loc(self, x:int, y:int, enemy:bool=False) -> bool:
        """
        Checks if the player or enemy can lay an egg at a specific location.

        Parameters:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.
            enemy (bool, optional): If True, checks for enemy; if False, checks for player.

        Returns:
            (bool): True if an egg can be laid at that location, False otherwise.
        """
        return self.game_board.can_lay_egg_at_loc(x, y, self.is_player_a != enemy)
    
    def can_lay_turd(self, enemy:bool = False) -> bool:
        """
        Checks if the player or enemy can lay a turd at their current location.

        Parameters:
            enemy (bool, optional): If True, checks for enemy; if False, checks for player.

        Returns:
            (bool): True if a turd can be laid, False otherwise.
        """
        return self.game_board.can_lay_turd(self.is_player_a != enemy)
    
    def can_lay_turd_at_loc(self, x:int, y:int, enemy:bool = False) -> bool:
        """
        Checks if the player or enemy can lay a turd at a specific location.

        Parameters:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.
            enemy (bool, optional): If True, checks for enemy; if False, checks for player.

        Returns:
            (bool): True if a turd can be laid at that location, False otherwise.
        """
        return self.game_board.can_lay_turd_at_loc(x, y, self.is_player_a != enemy)
    
    def set_trapdoor(self, x:int, y:int):
        """
        Sets a trapdoor at the specified location.

        Parameters:
            x (int): The x-coordinate for the trapdoor.
            y (int): The y-coordinate for the trapdoor.
        """
        return self.game_board.set_trapdoor(x, y)
    
    
    def is_my_turn(self, enemy:bool=False):
        """
        Checks if it is currently the player's or enemy's turn on the board.

        Parameters:
            enemy (bool, optional): If True, checks if it's enemy's turn; if False, checks if it's player's turn.

        Returns:
            (bool): True if it is the specified player's turn, False otherwise.
        """
        return self.game_board.a_to_play == (enemy != self.is_player_a)
    
    def get_winner(self) -> Result:
        """
        Returns the winner and reason for winning.

        Returns:
            (Result): A tuple containing the result and the reason for the win.
        """
        return self.game_board.get_winner()
    
    def get_time_left(self, enemy:bool=False) -> float:
        """
        Returns the time remaining for the player or enemy from the beginning of the turn.

        Parameters:
            enemy (bool, optional): If True, returns enemy's time; if False, returns player's time.

        Returns:
            (float): Time remaining in seconds.
        """
        return self.game_board.a_time if enemy!= self.is_player_a else self.game_board.b_time
    
    ######################################################
    # MOVE FUNCTIONS
    def apply_move(self, dir:Direction | int, move_type:MoveType | int, 
                   enemy:bool = False, check_ok:bool = True, 
                   reverse_perspective:bool =False) -> bool:
        """
        Applies a move to the board for the player or enemy.

        Parameters:
            dir (Direction or int): The direction of the move.
            move_type (MoveType or int): The type of move (plain, egg, turd).
            enemy (bool, optional): If True, applies move for enemy; if False, applies for player.
            check_ok (bool, optional): If True, validates the move before applying; if False, skips validation.
            reverse_perspective (bool, optional): If True, reverses perspective after applying the move.

        Returns:
            (bool): True if the move was successfully applied, False otherwise.
        """

        ok = self.game_board.apply_move(dir, move_type, enemy!=self.is_player_a, check_ok)

        if not ok:
            return False
        if reverse_perspective:
            self.reverse_perspective()
        return True
    
    def forecast_move(self, dir:Direction | int, move_type:MoveType | int, enemy:bool = False, 
                      check_ok:bool = True, reverse_perspective:bool = False) -> "PlayerBoard":
        """
        Creates a copy of the board with a forecasted move applied.

        Parameters:
            dir (Direction or int): The direction of the move.
            move_type (MoveType or int): The type of move (plain, egg, turd).
            enemy (bool, optional): If True, forecasts move for enemy; if False, forecasts for player.
            check_ok (bool, optional): If True, validates the move before applying; if False, skips validation.
            reverse_perspective (bool, optional): If True, reverses perspective after applying the move.

        Returns:
            (PlayerBoard): A new PlayerBoard object with the move applied, or None if the move is invalid.
        """
        player_board = self.get_copy()

        ok = player_board.apply_move(self, dir, move_type, enemy, 
                                     check_ok, reverse_perspective)
        if not ok:
            return None
        
        return player_board
    
    def get_valid_moves(self, enemy:bool=False) -> List[Tuple[Direction, MoveType]]:
        """
        Returns a list of all valid moves for the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns valid moves for enemy; if False, returns for player.

        Returns:
            (List[Tuple[Direction, MoveType]]): List of tuples containing valid direction and move type combinations.
        """
        valid_moves = []
        for dir in Direction:
            for move_type in MoveType:
                if(self.game_board.is_valid_move(dir, move_type, self.is_player_a != enemy)):
                    valid_moves.append((dir, move_type))

        return valid_moves
    
    #####################
    # CHICKEN FUNCTIONS #

    def get_spawn(self, enemy:bool=False) -> Tuple:
        """
        Returns the spawn location of the player's or enemy's chicken.

        Parameters:
            enemy (bool, optional): If True, returns enemy's spawn; if False, returns player's spawn.

        Returns:
            (Tuple): The (x, y) coordinates of the spawn location.
        """
        if(enemy):
            return self.chicken_enemy.get_spawn()
        return self.chicken_player.get_spawn()
    
    def get_location(self, enemy:bool=False) -> Tuple:
        """
        Returns the current location of the player's or enemy's chicken.

        Parameters:
            enemy (bool, optional): If True, returns enemy's location; if False, returns player's location.

        Returns:
            (Tuple): The (x, y) coordinates of the current location.
        """
        if(enemy):
            return self.chicken_enemy.get_location()
        return self.chicken_player.get_location()
    
    def get_num_eggs_laid(self, enemy:bool = False) -> int:
        """
        Returns the number of eggs laid by the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's egg count; if False, returns player's egg count.

        Returns:
            (int): Number of eggs laid.
        """
        if(enemy):
            return self.chicken_enemy.get_eggs_laid()
        return self.chicken_player.get_eggs_laid()
    
    def get_next_loc(self, dir:Direction, enemy:bool = False) -> Tuple:
        """
        Returns the next location if the chicken moves in the specified direction.

        Parameters:
            dir (Direction): The direction to move.
            enemy (bool, optional): If True, calculates for enemy; if False, calculates for player.

        Returns:
            (Tuple): The (x, y) coordinates of the next location.
        """
        if(enemy):
            return self.chicken_enemy.get_next_loc(dir)
        return self.chicken_player.get_next_loc(dir)
    
    def get_num_turds_placed(self, enemy:bool = False) -> int:
        """
        Returns the next location if the chicken moves in the specified direction.

        Parameters:
            dir (Direction): The direction to move.
            enemy (bool, optional): If True, calculates for enemy; if False, calculates for player.

        Returns:
            (Tuple): The (x, y) coordinates of the next location.
        """
        if(enemy):
            return self.chicken_enemy.get_turds_placed()
        return self.chicken_player.get_turds_placed()
    
    def get_num_turds_left(self, enemy:bool = False) -> int:
        """
        Returns the number of turds placed by the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's turd count; if False, returns player's turd count.

        Returns:
            (int): Number of turds placed.
        """
        if(enemy):
            return self.chicken_enemy.get_turds_left()
        return self.chicken_player.get_turds_left()
    
    def has_turds_left(self, enemy:bool = False) -> bool:
        """
        Returns the number of turds remaining for the player or enemy.

        Parameters:
            enemy (bool, optional): If True, returns enemy's remaining turds; if False, returns player's remaining turds.

        Returns:
            (int): Number of turds remaining.
        """
       
        if(enemy):
            return self.chicken_enemy.has_turds_left()
        return self.chicken_player.has_turds_left()

    
    #########################################
    ## PLAYER BOARD UTILITY FUNCTIONS
    def reverse_perspective(self):
        """
        Reverses the perspective from player to enemy or vice versa.
        This swaps all player and enemy references internally.
        """
        self.is_player_a = not self.is_player_a

        self.chicken_player, self.chicken_enemy = self.chicken_enemy, self.chicken_player

        self.player_cells_blocked, self.enemy_cells_blocked = self.enemy_cells_blocked, self.player_cells_blocked
        self.player_egg_list, self.enemy_egg_list = self.enemy_egg_list, self.player_egg_list

        self.player_turd_list, self.enemy_turd_list = self.enemy_turd_list, self.player_turd_list

    def get_copy(self):
        """
        Creates a deep copy of the current PlayerBoard.

        Returns:
            (PlayerBoard): A new PlayerBoard object with the same state as the current one.
        """
        return PlayerBoard(self.is_player_a, self.game_board.get_copy())


    

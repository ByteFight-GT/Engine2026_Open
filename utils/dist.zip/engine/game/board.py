import numpy as np
import json

from game.game_map import GameMap
from game.enums import Direction, Result, MoveType, Cell, WinReason
from game.chicken import Chicken
from game.history import History
from collections.abc import Iterable
from typing import Tuple


class Board():
    """
    Board is the game engine's representation of the current match.

    Any coordinates should be given to the board in the form of x, y.
    Game objects are displayed, indexed, and stored on the 
    board arrays as y, x for geometrical accuracy.

    Check_validity is on by default for most functions, but slows
    down execution. If a player is confident their actions are valid,
    they can directly apply turns and moves with check_validity as false.

    Be wary that invalid actions/turns could lead to functions throwing
    errors, so make sure to handle them with a try/except in case so that
    your program doesn't crash. If an apply function throws an error,
    it is not guarenteed that the board state will be valid or that the state
    will be the same as when the function started.
    """  
    def __init__(self, game_map: GameMap, time_to_play: float = 20, 
                 build_history: bool = False, randomize:bool = False, copy: bool = False):
        """
        Initializes the board with the specified game map and configuration options.

        Parameters:  
            game_map (game_map.GameMap): The map representing the game environment.  
            time_to_play (float, optional): The time limit for the game in seconds. Defaults to 20.  
            build_history (bool, optional): Whether to track the history of the game. Defaults to False.  
            randomize (bool, optional): Whether to randomize trapdoor sampling. Defaults to False.
            copy (bool, optional): Whether to initialize a copy of the game game_map. Defaults to False.  
        """

        self.game_map = game_map
        
        if(not copy):
            #map metadata
            self.cells_blocked_a = np.zeros((self.game_map.MAP_SIZE, self.game_map.MAP_SIZE), dtype = np.uint8)
            self.cells_blocked_b = np.zeros((self.game_map.MAP_SIZE, self.game_map.MAP_SIZE), dtype = np.uint8)
            self.cells_eggsturds = np.zeros((self.game_map.MAP_SIZE, self.game_map.MAP_SIZE), dtype = np.uint8)
            
            self.egg_list_a = list()
            self.egg_list_b = list()
            self.turd_list_a = list()
            self.turd_list_b = list()
            
            self.chicken_a = Chicken(self.game_map.MAX_TURDS)
            self.chicken_b = Chicken(self.game_map.MAX_TURDS)

            self.cells_trapdoors = np.zeros((self.game_map.MAP_SIZE, self.game_map.MAP_SIZE), dtype = np.uint8)
            self.trapdoors = list()

            self.randomize = randomize
            self.trapdoors_marked = 0

            if(self.randomize):
                self.hear_sampling_masks = np.zeros(
                    (2 * self.game_map.NUM_TRAPDOORS_PER_TEAM, self.game_map.MAP_SIZE, self.game_map.MAP_SIZE)
                )
                self.feel_sampling_masks = np.zeros(
                    (2 * self.game_map.NUM_TRAPDOORS_PER_TEAM, self.game_map.MAP_SIZE, self.game_map.MAP_SIZE)
                )

            def init_game():
                trapdoors_a, trapdoors_b, spawn_a, spawn_b = self.game_map.get_trapdoors_and_spawns()
                self.chicken_a.start(spawn_a, 0)
                self.chicken_b.start(spawn_b, 1)

                for x, y in trapdoors_a:
                    self.set_trapdoor(x, y)

                for x, y in trapdoors_b:
                    self.set_trapdoor(x, y)
            
            init_game()


            #game metadata
            self.turn_count = 0

            self.MAX_TURNS = 20
            self.turns_left_a = self.MAX_TURNS
            self.turns_left_b = self.MAX_TURNS          

            #more game metadata
            self.a_to_play = True
            self.winner = None

            self.time_to_play = time_to_play
            self.a_time = time_to_play
            self.b_time = time_to_play
            self.win_reason = None    

            self.chicken_blocked = False        

            #history building
            self.build_history = build_history
            if(build_history):
                self.history = History()

    def is_valid_cell(self, x:int, y:int):
        """
        Checks if the given coordinates are within the valid board boundaries.

        Parameters:
            x (int): The x-coordinate to check.
            y (int): The y-coordinate to check.

        Returns:
            (bool): True if the cell is valid, False otherwise.
        """
        return x >= 0 and y >= 0 and x < self.game_map.MAP_SIZE and y <self.game_map.MAP_SIZE
    
    def is_cell_blocked(self, x:int, y:int, player_a:bool):
        """
        Checks if a specific cell is blocked for the given player.

        Parameters:
            x (int): The x-coordinate of the cell.
            y (int): The y-coordinate of the cell.
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if the cell is blocked or occupied by the enemy chicken, False otherwise.
        """
        cells_blocked = self.cells_blocked_a if player_a else self.cells_blocked_b
        chicken_enemy = self.chicken_b if player_a else self.chicken_a
        enemy_x, enemy_y = chicken_enemy.get_location()

        return self.is_valid_cell(x, y) and \
            (cells_blocked[y,x] or (x==enemy_x and y == enemy_y))
    
    def is_valid_move(self, dir:Direction|int,  move_type:MoveType|int, player_a:bool):
        """
        Checks if a move is valid for the given player.

        Parameters:
            dir (Direction | int): The direction of the move.
            move_type (MoveType | int): The type of move (walk, egg, turd).
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if the move is valid, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b
        chicken_enemy = self.chicken_b if player_a else self.chicken_a
        cells_blocked = self.cells_blocked_a if player_a else self.cells_blocked_b

        move_ok = int(dir) >= 0 and int(dir) < 4 and int(move_type) >=0 and int(move_type) < 3
        
        if not move_ok:
            return False
        
        x, y = chicken_player.get_location()
        next_x, next_y = chicken_player.get_next_loc(dir)
        enemy_x, enemy_y = chicken_enemy.get_location()

        # print(next_x, next_y)
        # print(enemy_x, enemy_y)

        

        dir_ok = self.is_valid_cell(next_x, next_y) \
            and not cells_blocked[next_y,next_x]  \
            and not (enemy_x==next_x and enemy_y==next_y)

        lay_ok  = True
        if(move_type == MoveType.EGG):
            lay_ok = chicken_player.can_lay_egg(x, y) and self.cells_eggsturds[y, x] == 0
        elif(move_type  == MoveType.TURD):
            lay_ok = chicken_player.has_turds_left() and np.abs(enemy_x-x)+np.abs(enemy_y-y) > 1 \
                and self.cells_eggsturds[y, x] == 0

        return dir_ok and lay_ok
    
    def can_lay_egg(self, player_a:bool):
        """
        Checks if the player can lay an egg at their current location.

        Parameters:
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if an egg can be laid, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b

        x, y = chicken_player.get_location()
        return chicken_player.can_lay_egg(x, y) and self.cells_eggsturds[y, x] == 0
    
    def can_lay_egg_at_loc(self, x:int, y:int, player_a:bool):
        """
        Checks if the player can lay an egg at a specific location.

        Parameters:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if an egg can be laid at that location, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b

        return chicken_player.can_lay_egg(x, y) and self.cells_eggsturds[y, x] == 0
    
    def can_lay_turd(self, player_a:bool):
        """
        Checks if the player can lay a turd at their current location.

        Parameters:
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if a turd can be laid, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b
        chicken_enemy = self.chicken_b if player_a else self.chicken_a

        x, y = chicken_player.get_location()
        enemy_x, enemy_y = chicken_enemy.get_location()
        return chicken_player.has_turds_left() and np.abs(enemy_x-x)+np.abs(enemy_y-y) > 1 \
            and self.cells_eggsturds[y, x] == 0
    
    def can_lay_turd_at_loc(self, x:int, y:int, player_a:bool):
        """
        Checks if the player can lay a turd at a specific location.

        Parameters:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if a turd can be laid at that location, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b
        chicken_enemy = self.chicken_b if player_a else self.chicken_a

        enemy_x, enemy_y = chicken_enemy.get_location()
        return chicken_player.has_turds_left() and np.abs(enemy_x-x)+np.abs(enemy_y-y) > 1 \
            and self.cells_eggsturds[y, x] == 0
    

    def apply_move(self, dir:Direction | int, move_type:MoveType | int, player_a:bool, timer:float = 0, check_ok:bool = True):
        """
        Applies a move to the board for the specified player.

        Parameters:
            dir (Direction | int): The direction of the move.
            move_type (MoveType | int): The type of move (walk, egg, turd).
            player_a (bool): If True, applies move for player A; if False, applies for player B.
            timer (float, optional): Time taken for the move in seconds. Defaults to 0.
            check_ok (bool, optional): If True, validates the move before applying; if False, skips validation. Defaults to True.

        Returns:
            (bool): True if the move was successfully applied, False otherwise.
        """
        chicken_player = self.chicken_a if player_a else self.chicken_b
        
        move_offset = 0 if player_a else 2
        # TODO: put in try/except 
        # try:

        
        if(check_ok):
            if(not self.is_valid_move(dir, move_type, player_a)):
                return False
            
        x, y = chicken_player.get_location()
        
        if(move_type == MoveType.EGG):
            egg_list = self.egg_list_a if player_a else self.egg_list_b
            blocked_cells = self.cells_blocked_b if player_a else self.cells_blocked_a

            chicken_player.increment_eggs_laid()     
            egg_list.append((x, y))           
            self.cells_eggsturds[y, x] = move_type + move_offset
            blocked_cells[y, x] = 1


        elif(move_type  == MoveType.TURD):
            turd_list = self.turd_list_a if player_a else self.turd_list_b
            blocked_cells = self.cells_blocked_b if player_a else self.cells_blocked_a

            chicken_player.decrement_turds()
            turd_list.append((x, y))
            self.cells_eggsturds[y, x] = move_type + move_offset

            blocked_cells[y,x] = 1
            if(self.is_valid_cell(x, y-1)):
                blocked_cells[y-1,x] = 1
            if(self.is_valid_cell(x+1, y)):
                blocked_cells[y,x+1] = 1
            if(self.is_valid_cell(x, y+1)):
                blocked_cells[y+1,x] = 1
            if(self.is_valid_cell(x-1, y)):
                blocked_cells[y,x-1] = 1
            
        next_x, next_y = chicken_player.apply_dir(dir)
        # print(next_x, next_y)

        trigger_trap = self.cells_trapdoors[next_y,next_x] == Cell.TRAPDOOR
        if(self.build_history):
            self.history.record_trapdoor(1 if trigger_trap else 0)

        if(trigger_trap):
            chicken_enemy = self.chicken_b if player_a else self.chicken_a
            chicken_enemy.increment_eggs_laid(2)
            chicken_player.reset_location()

        self.end_turn(move_type, player_a, timer)
            
            
        return True
        # except:
        #     return False
        

    def end_turn(self, move_type:MoveType, player_a:bool, timer=0):
        """
        Ends the current turn and updates game state.

        Parameters:
            move_type (MoveType): The type of move that was made.
            player_a (bool): If True, ends turn for player A; if False, ends for player B.
            timer (float, optional): Time taken for the turn in seconds. Defaults to 0.
        """
        if(player_a):
            self.turns_left_a -= 1
            self.a_time -= timer
        else:
            self.turns_left_b -= 1
            self.b_time -= timer
        self.turn_count +=1

        chicken_player = self.chicken_a if player_a else self.chicken_b
        
        if(not self.has_moves_left(not player_a)):
            print(self.cells_blocked_a)
            print(self.cells_blocked_b)
            print(player_a)
            enemy_turns_left = self.turns_left_b if player_a else self.turns_left_a
            if(enemy_turns_left > 0):
                chicken_player.increment_eggs_laid(2)
                self.chicken_blocked = True


        self.check_win()
        self.a_to_play = not self.a_to_play

        if(self.build_history):
            self.history.record_round_update(
                chicken_player.get_location(),
                move_type,
                self.chicken_a.get_eggs_laid(),
                self.chicken_b.get_eggs_laid(),
                self.chicken_a.get_turds_left(),
                self.chicken_b.get_turds_left(),
                self.a_time,
                self.b_time,
                self.turns_left_a,
                self.turns_left_b
            )

    def check_win(self, timeout_bounds: float = 0.5):
        """
        Checks if the game has been won and sets the winner accordingly.

        Parameters:
            timeout_bounds (float, optional): The time threshold in seconds for determining timeout ties. Defaults to 0.5.
        """
        if(self.a_time <=0):
            if(self.b_time <= timeout_bounds):
                self.set_winner(Result.TIE, WinReason.TIMEOUT)
            else:
                self.set_winner(Result.PLAYER_B, WinReason.TIMEOUT)
        elif(self.b_time <=0):
            if(self.a_time <= timeout_bounds):
                self.set_winner(Result.TIE, WinReason.TIMEOUT)
            else:
                self.set_winner(Result.PLAYER_A, WinReason.TIMEOUT)
        elif(self.turns_left_a==0 and self.turns_left_b==0):
            if(self.chicken_a.get_eggs_laid() < self.chicken_b.get_eggs_laid()):
                self.set_winner(Result.PLAYER_B, WinReason.EGGS_LAID)
            elif(self.chicken_a.get_eggs_laid() > self.chicken_b.get_eggs_laid()):
                self.set_winner(Result.PLAYER_A, WinReason.EGGS_LAID)
            else:
                self.set_winner(Result.TIE, WinReason.EGGS_LAID)
        elif(self.chicken_blocked): 
            # seperate condition in case we want to change outcome of blocking win
            if(self.chicken_a.get_eggs_laid() < self.chicken_b.get_eggs_laid()):
                self.set_winner(Result.PLAYER_B, WinReason.BLOCKING_END)
            elif(self.chicken_a.get_eggs_laid() > self.chicken_b.get_eggs_laid()):
                self.set_winner(Result.PLAYER_A, WinReason.BLOCKING_END)
            else:
                self.set_winner(Result.TIE, WinReason.BLOCKING_END)

    def is_game_over(self):
        """
        Checks if the game is over.

        Returns:
            (bool): True if the game is over, False otherwise.
        """
        return self.winner is not None
        
    def forecast_move(self, dir:Direction | int, move_type: MoveType | int, player_a:bool, check_ok:bool = True):
        """
        Creates a copy of the board with a forecasted move applied.

        Parameters:
            dir (Direction | int): The direction of the move.
            move_type (MoveType | int): The type of move (walk, egg, turd).
            player_a (bool): If True, forecasts move for player A; if False, forecasts for player B.
            check_ok (bool, optional): If True, validates the move before applying; if False, skips validation. Defaults to True.

        Returns:
            (Board): A new Board object with the move applied, or None if the move is invalid.
        """
        board_copy = self.get_copy()
        ok = board_copy.apply_move(dir, move_type, player_a, check_ok)
        return board_copy if ok else None

    def get_trapdoor_samples(self, player_a:bool):
        """
        Returns trapdoor sampling data for the specified player.

        Parameters:
            player_a (bool): If True, gets samples for player A; if False, gets samples for player B.

        Returns:
            (List[Tuple[bool, bool]]): List of tuples containing (hear, feel) samples for each trapdoor.
        """
        
        if(self.randomize):
            chicken_player = self.chicken_a if player_a else self.chicken_b
            x, y = chicken_player.get_location()

            

            sample_tuples = []
            for i in range(len(self.hear_sampling_masks)):

                hear = np.random.random() < self.hear_sampling_masks[i, y,x]
                feel =  np.random.random() < self.feel_sampling_masks[i, y,x]
                sample_tuples.append((hear, feel))

            return sample_tuples
        else:
            return [(False, False) for i in range(2* self.game_map.NUM_TRAPDOORS_PER_TEAM)]

    def set_trapdoor(self, x:int, y:int):
        """
        Sets a trapdoor at the specified location and updates sampling masks if randomization is enabled.

        Parameters:
            x (int): The x-coordinate for the trapdoor.
            y (int): The y-coordinate for the trapdoor.
        """
        self.cells_trapdoors[y,x] = Cell.TRAPDOOR
        self.trapdoors.append((x, y))
        if(self.randomize):
            
            for base_mask, sampling_masks in [
                (self.game_map.hear_base_mask, self.hear_sampling_masks),
                (self.game_map.feel_base_mask, self.feel_sampling_masks)]:


                mask_x, mask_y = base_mask.shape[1]//2, base_mask.shape[0]//2

                # Get slices
                x_start = max(x - mask_x, 0)
                y_start = max(y - mask_y, 0)
                x_end = min(x + mask_x + 1, self.game_map.MAP_SIZE)
                y_end = min(y + mask_y + 1, self.game_map.MAP_SIZE)

                # Corresponding mask slice (in case the mask goes off the edge)
                mask_x_start = mask_x - (x - x_start)
                mask_y_start = mask_y - (y - y_start)
                mask_x_end = mask_x_start + (x_end - x_start)
                mask_y_end = mask_y_start + (y_end - y_start)

                sampling_masks[self.trapdoors_marked, y_start:y_end, x_start:x_end] = \
                    base_mask[mask_y_start:mask_y_end, mask_x_start:mask_x_end]

        self.trapdoors_marked += 1

    def get_copy(self, build_history:bool = False, randomize:bool = None):
        """
        Creates a deep copy of the current board.

        Parameters:
            build_history (bool, optional): Whether the copy should track history. Defaults to False.
            randomize (bool, optional): Whether the copy should use randomization. If None, uses current setting. Defaults to None.

        Returns:
            (Board): A new Board object with the same state as the current one.
        """
        board_copy = Board(self.game_map, build_history=build_history, randomize=randomize, copy=True)
        board_copy.cells_blocked_a = np.array(self.cells_blocked_a)
        board_copy.cells_blocked_b = np.array(self.cells_blocked_b)
        board_copy.cells_eggsturds = np.array(self.cells_eggsturds)
        
        board_copy.egg_list_a = self.egg_list_a[:]
        board_copy.egg_list_b = self.egg_list_b[:]
        board_copy.turd_list_a = self.turd_list_a[:]
        board_copy.turd_list_b = self.turd_list_b[:]

        board_copy.chicken_a = self.chicken_a.get_copy()
        board_copy.chicken_b = self.chicken_b.get_copy()

        board_copy.randomize = self.randomize if randomize is None else randomize
        if(board_copy.randomize):
            board_copy.trapdoors_marked = self.trapdoors_marked
            board_copy.cells_trapdoors = np.array(self.cells_trapdoors)
            board_copy.trapdoors = self.trapdoors[:]

            board_copy.hear_sampling_masks = np.array(self.hear_sampling_masks)
            board_copy.feel_sampling_masks = np.array(self.feel_sampling_masks)
        else:
            board_copy.trapdoors_marked = 0
            board_copy.cells_trapdoors = np.zeros_like(self.cells_trapdoors)
            board_copy.trapdoors = []


        #game metadata
        board_copy.turn_count = self.turn_count

        board_copy.MAX_TURNS = self.MAX_TURNS
        board_copy.turns_left_a = self.turns_left_a
        board_copy.turns_left_b = self.turns_left_b

        #more game metadata
        board_copy.a_to_play = self.a_to_play
        board_copy.winner = self.winner

        board_copy.time_to_play = self.time_to_play
        board_copy.a_time = self.a_time
        board_copy.b_time = self.b_time
        board_copy.win_reason = self.win_reason
        board_copy.chicken_blocked = self.chicken_blocked        

        #history building
        board_copy.build_history = build_history
        if(build_history):
            board_copy.history = self.history

        return board_copy

    def has_trapdoor(self, x:int, y:int):
        """
        Checks if a specific cell has a trapdoor.

        Parameters:
            x (int): The x-coordinate of the cell.
            y (int): The y-coordinate of the cell.

        Returns:
            (bool): True if there is a trapdoor at that location, False otherwise.
        """
        return self.cells_trapdoors[y,x] > 0
    
    def get_blocked_cells_arr(self, player_a:bool):
        """
        Returns an array of blocked cells for the specified player.

        Parameters:
            player_a (bool): If True, gets blocked cells for player A; if False, gets for player B.

        Returns:
            (np.ndarray): Boolean array where True indicates blocked cells.
        """
        blocked_cells = self.cells_blocked_b if player_a else self.cells_blocked_b
        return blocked_cells > 0

    def has_moves_left(self, player_a:bool):
        """
        Checks if the player has any valid moves remaining.

        Parameters:
            player_a (bool): If True, checks for player A; if False, checks for player B.

        Returns:
            (bool): True if there are valid moves remaining, False otherwise.
        """
        cells_blocked = self.cells_blocked_a if player_a else self.cells_blocked_b
        x, y = self.chicken_a.get_location() if player_a else self.chicken_b.get_location()
        chicken_enemy = self.chicken_b if player_a else self.chicken_a
        enemy_x, enemy_y = chicken_enemy.get_location()
        ### TODO: CHECK ENEMY BLOCKING INTO END
        return (self.is_valid_cell(x+1, y) and not cells_blocked[y,x+1] and not (enemy_x== x+1 and enemy_y==y)) or \
            (self.is_valid_cell(x-1, y) and not cells_blocked[y,x-1] and not (enemy_x== x-1 and enemy_y==y)) or \
            (self.is_valid_cell(x, y+1) and not cells_blocked[y+1,x] and not (enemy_x== x and enemy_y==y+1)) or \
            (self.is_valid_cell(x, y-1) and not cells_blocked[y-1,x] and not (enemy_x== x and enemy_y==y-1))

        
    def is_as_turn(self) -> bool:
        """
        Returns:  
            (bool): If it is player A's turn to play.  
        """
        return self.a_to_play

    def get_a_time(self) -> float:
        """
        Returns:  
            (float): Time in seconds that player A has to make a turn.    
        """
        return self.a_time

    def get_b_time(self) -> float:
        """
        Returns:  
            (float): Time in seconds that player B has to make a turn.  
        """
        return self.b_time
    
    def set_build_history(self, build_history: bool):
        """
        Sets whether the history of the game should be recorded.

        Parameters:  
            build_history (bool): Whether to track the game history. True to record, False to not record.
        """

        self.build_history = build_history

    def set_winner(self, result: Result, reason:WinReason):
        """
        Sets the winner and the reason for the game's outcome.

        Parameters:  
            result (Result): The winner of the game.
            reason (WinReason): The reason for the outcome.
        """

        self.winner = result
        self.win_reason = reason


    def get_winner(self) -> Result:
        """
        Returns the winner of the game.

        Returns:  
            (Result): The winner of the game.
        """

        return self.winner

    def get_win_reason(self) -> str:
        """
        Returns the string explaining the reason why the game was won.

        Returns:  
            (str): The reason for the game's outcome.
        """
        return self.win_reason


    def get_history(self) -> dict:
        """
        Get a dictionary representation for the renderer.

        Returns:  
            (dict): A dictionary representing the game history.
        """
        return self.history
from game.enums import Direction
import numpy as np
from typing import Tuple

class Chicken:
    """
    This class represents a chicken.
    """
    def __init__(self, max_turds:int = 0, copy:bool = False):
        """
        Initializes the Chicken object with copy flag.

        Parameters:
            max_turds (int, optional): Maximum number of turds the chicken can place. Defaults to 0.
            copy (bool, optional): If True, initializes as an empty copy; if False, initializes with default values. Defaults to False.
        """
        
        if(not copy):
            self.turds_left = max_turds
            self.eggs_laid = 0


    def start(self, start_loc:Tuple[int, int], even_chicken:int):
        """
        Initializes the chicken's starting position and parity.

        Parameters:
            start_loc (Tuple[int, int]): The (x, y) coordinates of the starting location.
            even_chicken (int): The parity indicator (0 or 1) that determines which cells the chicken can lay eggs on.
        """
        self.spawn = np.array(start_loc)
        self.loc = np.array(start_loc)
        self.even_chicken = even_chicken


    def get_spawn(self):
        """
        Returns a copy of the chicken's spawn location.

        Returns:
            (np.ndarray): Array containing the (x, y) coordinates of the spawn location.
        """
        return np.array(self.spawn)

    def get_location(self) -> np.ndarray:
        """
        Returns a copy of the chicken's current location.

        Returns:
            (np.ndarray): Array containing the (x, y) coordinates of the current location.
        """
        return np.array(self.loc)
    
    def increment_eggs_laid(self, eggs=1) -> np.ndarray:
        """
        Increments the count of eggs laid by the chicken.

        Parameters:
            eggs (int, optional): Number of eggs to add to the count. Defaults to 1.
        """
        self.eggs_laid += eggs
    
    def reset_location(self):
        """
        Resets the chicken's location back to its spawn point.
        """
        self.loc = np.array(self.spawn)
    
    def can_lay_egg(self, x:int, y:int):
        """
        Checks if the chicken can lay an egg at the specified location based on parity.

        Parameters:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.

        Returns:
            (bool): True if the chicken can lay an egg at that location, False otherwise.
        """
        return (x + y) % 2 == self.even_chicken
    
    def decrement_turds(self):
        """
        Decrements the count of turds remaining.
        """
        self.turds_left -= 1
    
    def get_turds_left(self) -> int:
        """
        Returns the number of turds remaining.

        Returns:
            (int): Number of turds left.
        """
        return self.turds_left
    
    def get_turds_placed(self) -> int:
        """
        Returns the number of turds that have been placed.

        Returns:
            (int): Number of turds placed.
        """
        return 5 - self.turds_left
    
    def get_eggs_laid(self):
        """
        Returns the number of eggs laid by the chicken.

        Returns:
            (int): Number of eggs laid.
        """
        return self.eggs_laid

    def get_next_loc(self, dir = Direction|int, loc=None) -> np.ndarray:
        """
        Returns the next location if the chicken moves in the specified direction. Does not apply the move.

        Parameters:
            dir (Direction | int): The direction to move.
            loc (np.ndarray, optional): The starting location. If None, uses current location. Defaults to None.

        Returns:
            (np.ndarray): Array containing the (x, y) coordinates of the next location, or None if direction is invalid.
        """
        loc = np.array(self.loc) if (loc is None) else np.array(loc)
    
        match dir:
            case Direction.UP:
                loc[1]-=1
            case Direction.RIGHT:
                loc[0]+=1
            case Direction.DOWN:
                loc[1]+=1
            case Direction.LEFT:
                loc[0]-=1

            case _:
                return None
            
        return loc
    

    def apply_dir(self, dir = Direction|int) -> np.ndarray:
        """
        Applies a direction to move the chicken and updates its location.

        Parameters:
            dir (Direction | int): The direction to move.

        Returns:
            (np.ndarray): Array containing the new (x, y) coordinates, or None if direction is invalid.
        """
        match dir:
            case Direction.UP:
                self.loc[1]-=1
            case Direction.RIGHT:
                self.loc[0]+=1
            case Direction.DOWN:
                self.loc[1]+=1
            case Direction.LEFT:
                self.loc[0]-=1
            case _:
                return None
            
        return np.array(self.loc)
            
    def lay_egg(self):
        """
        Lays an egg at the chicken's current location and increments the egg count.

        Returns:
            (np.ndarray): Array containing the (x, y) coordinates where the egg was laid.
        """
        self.eggs_laid += 1
        return np.array(self.loc)
    
    def drop_turd(self):
        """
        Drops a turd at the chicken's current location and decrements the turd count.

        Returns:
            (np.ndarray): Array containing the (x, y) coordinates where the turd was dropped.
        """
        self.turds_left -= 1
        return np.array(self.loc)

    def has_turds_left(self):
        """
        Checks if the chicken has turds remaining.

        Returns:
            (bool): True if there are turds remaining, False otherwise.
        """
        return self.turds_left > 0
    
    
    def get_copy(self) -> "Chicken":
        """
        Return a deep copy of the chicken.

        Returns:  
            (Chicken): A deep copy of the current chicken object.
        """

        new_chicken = Chicken(copy = True)
        
        new_chicken.even_chicken = self.even_chicken
        new_chicken.eggs_laid = self.eggs_laid
        new_chicken.turds_left = self.turds_left
        new_chicken.loc = np.array(self.loc)
        new_chicken.spawn = self.spawn

        return new_chicken
from enum import IntEnum, auto
class Result(IntEnum):
    PLAYER_A = 0
    PLAYER_B = 1
    TIE = 2
    ERROR = 3

class Direction(IntEnum):
    UP = 0
    RIGHT = 1
    DOWN = 2
    LEFT = 3

class MoveType(IntEnum):
    PLAIN = 0
    EGG = 1
    TURD = 2

class Cell(IntEnum):
    SPACE = 0
    PLAYER_A_EGG = 1
    PLAYER_A_TURD = 2
    PLAYER_B_EGG = 3
    PLAYER_B_TURD = 4
    TRAPDOOR = 6

class WinReason(IntEnum):
    EGGS_LAID = 0
    BLOCKING_END = 1
    TIMEOUT = 2
    INVALID_TURN = 3
    CODE_CRASH = 4
    MEMORY_ERROR = 5
    FAILED_INIT = 6




    

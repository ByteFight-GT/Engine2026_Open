

def main():
    import os    
    import argparse
    import sys
    from gameplay import play_game
    from game.enums import Result
    from board_utils import get_history_json
    import time

    parser = argparse.ArgumentParser(description='Run a game between two players')
    
   
    parser.add_argument('--a_name', '-a', type=str, help='Name of player A submission', required=True)
    parser.add_argument('--b_name', '-b', type=str, help='Name of player B submission', required=True)

    parser.add_argument('--no_display', action='store_true', dest='display_game', help="Do not display the game (override default: False)")
    parser.add_argument('--delay', type=float, default=0.1, help="Delay between game actions (default: 0.1)")
    parser.add_argument('--game_directory', type=str, default="workspace", help="Location where your agents are located")
    parser.add_argument('--no_clear_screen', action='store_true', dest='clear_screen', help="Do not clear screen (override default: False)")


    args = parser.parse_args(sys.argv[1:])
    play_directory = os.path.join(os.getcwd(), args.game_directory) 
    
    
    sim_time = time.perf_counter()


    final_board, err_a, err_b = play_game(play_directory, play_directory, 
                                        args.a_name, args.b_name, 
                                        display_game=not args.no_display, 
                                        delay = args.delay, 
                                        clear_screen = not args.no_clear_screen, 
                                        record = True, limit_resources=False)  
    
    sim_time = time.perf_counter() - sim_time
    
    turn_count = final_board.turn_count
    print(f"{sim_time} seconds elapsed for {turn_count} rounds.")

    out_file = 'result.json'
    out_dir = os.path.join(play_directory, "match_runs") 

    if not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    with open(os.path.join(out_dir, out_file), 'w') as fp:
        fp.write(get_history_json(final_board))

    
   


if __name__=="__main__":
    main()
